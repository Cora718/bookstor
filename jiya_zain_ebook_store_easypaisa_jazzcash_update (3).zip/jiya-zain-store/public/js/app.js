'use strict';

const $ = (id) => document.getElementById(id);
let activeCurrency = 'PKR';
let currentBook = null;

function money(amountMinor, currency) {
  if (currency === 'PKR') return new Intl.NumberFormat('en-PK', { style: 'currency', currency: 'PKR', maximumFractionDigits: 0 }).format(amountMinor / 100);
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amountMinor / 100);
}

function currencyForCountry(country) { return country === 'Pakistan' ? 'PKR' : 'USD'; }
function updatePrice() {
  if (!currentBook) return;
  const country = $('countrySelect')?.value || 'Pakistan';
  activeCurrency = currencyForCountry(country);
  const amount = currentBook.price[activeCurrency];
  $('bookPrice').textContent = money(amount, activeCurrency);
  $('formPrice').textContent = money(amount, activeCurrency);
  $('priceCaption').textContent = `One-time price · PDF eBook · ${activeCurrency}`;
  $('priceFootnote').textContent = activeCurrency === 'PKR'
    ? 'Pakistan price. Your bank or payment provider may apply separate charges.'
    : 'International price in US dollars. Your bank may apply its own currency conversion or fees.';
  $('pakistanPrice').classList.toggle('active', activeCurrency === 'PKR');
  $('internationalPrice').classList.toggle('active', activeCurrency === 'USD');
}

async function loadBook() {
  try {
    const response = await fetch('/api/book');
    if (!response.ok) throw new Error('Book details could not be loaded.');
    const data = await response.json();
    currentBook = data.book;
    $('bookTitle').textContent = currentBook.title;
    $('bookSubtitle').textContent = currentBook.subtitle;
    $('bookDescription').textContent = currentBook.description;
    $('bookPages').textContent = currentBook.pages || '178';
    updatePrice();
  } catch (error) {
    const feedback = $('formFeedback');
    if (feedback) { feedback.textContent = error.message; feedback.classList.add('error'); }
  }
}

function setCountryPrice() { updatePrice(); }
$('countrySelect')?.addEventListener('change', () => { setCountryPrice(); updatePaymentChoices(); });
$('paymentMethod')?.addEventListener('change', updatePaymentInstructions);
function updatePaymentChoices() {
  const pakistan = $('countrySelect')?.value === 'Pakistan';
  const select = $('paymentMethod');
  if (!select) return;
  for (const option of select.options) {
    if (option.value === 'easypaisa' || option.value === 'jazzcash') option.hidden = !pakistan;
    if (option.value === 'international_arrangement') option.hidden = pakistan;
  }
  if ((pakistan && select.value === 'international_arrangement') || (!pakistan && ['easypaisa','jazzcash'].includes(select.value))) select.value = '';
  updatePaymentInstructions();
}
function updatePaymentInstructions() {
  const method = $('paymentMethod')?.value;
  const messages = {
    easypaisa: 'Easypaisa selected. After your order is received, the store will email verified merchant payment instructions. Do not transfer money to an unverified number.',
    jazzcash: 'JazzCash selected. After your order is received, the store will email verified merchant payment instructions. Do not transfer money to an unverified number.',
    international_arrangement: 'International payment will be arranged by email. Your order is not paid until the store verifies the payment.',
  };
  if ($('paymentInstructions')) $('paymentInstructions').textContent = messages[method] || 'Choose a method. For Easypaisa or JazzCash, the store will send verified merchant payment instructions after your order is received. Do not transfer money to an unverified number.';
}

$('pakistanPrice')?.addEventListener('click', () => { $('countrySelect').value = 'Pakistan'; updatePrice(); });
$('internationalPrice')?.addEventListener('click', () => { $('countrySelect').value = 'United States'; updatePrice(); });

$('mobileMenu')?.addEventListener('click', () => {
  const nav = $('mainNav');
  const open = nav.classList.toggle('open');
  $('mobileMenu').setAttribute('aria-expanded', String(open));
});
$('mainNav')?.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
  $('mainNav').classList.remove('open');
  $('mobileMenu')?.setAttribute('aria-expanded', 'false');
}));

$('orderForm')?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const feedback = $('formFeedback');
  const button = form.querySelector('button[type="submit"]');
  feedback.classList.remove('error');
  feedback.textContent = 'Submitting your order request…';
  button.disabled = true;
  try {
    const values = Object.fromEntries(new FormData(form).entries());
    values.currency = currencyForCountry(values.country);
    values.format = 'PDF';
    values.paymentMethod = values.paymentMethod || '';
    values.paymentReference = (values.paymentReference || '').trim();
    const response = await fetch('/api/orders', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(values)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Order request could not be submitted.');
    feedback.textContent = `Your order ${data.orderNumber} has been saved. Payment method: ${data.paymentMethodLabel}. The store will send verified payment instructions. This is not a payment confirmation; your eBook is delivered only after payment is verified.`;
    form.reset();
    $('countrySelect').value = 'Pakistan';
    updatePrice(); updatePaymentChoices();
  } catch (error) {
    feedback.textContent = error.message;
    feedback.classList.add('error');
  } finally {
    button.disabled = false;
  }
});

updatePaymentChoices();
loadBook();
