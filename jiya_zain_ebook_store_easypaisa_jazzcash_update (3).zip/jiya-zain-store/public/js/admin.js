'use strict';
const byId = (id) => document.getElementById(id);
const feedback = (id, message, error = false) => { const el = byId(id); el.textContent = message; el.classList.toggle('error', error); };
async function api(url, options = {}) {
  const response = await fetch(url, { credentials: 'same-origin', ...options, headers: { ...(options.headers || {}) } });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || 'Request failed.');
  return body;
}
function showDashboard(admin) {
  byId('loginPanel').classList.add('admin-hidden');
  byId('dashboardPanel').classList.remove('admin-hidden');
  byId('adminIdentity').textContent = `Signed in as ${admin.email}`;
  loadAdminData();
}
async function loadAdminData() {
  try {
    const [{ book }, { orders }] = await Promise.all([api('/api/admin/book'), api('/api/admin/orders')]);
    const form = byId('bookForm');
    form.elements.title.value = book.title;
    form.elements.subtitle.value = book.subtitle;
    form.elements.description.value = book.description;
    form.elements.priceUsd.value = (book.price.USD / 100).toFixed(2);
    form.elements.pricePkr.value = (book.price.PKR / 100).toFixed(0);
    const body = byId('ordersBody');
    if (!orders.length) { body.innerHTML = '<tr><td colspan="8">No orders have been received yet.</td></tr>'; return; }
    body.replaceChildren();
    for (const order of orders) {
      const tr = document.createElement('tr');
      const values = [order.orderNumber, `${order.name}\n${order.email}\n${order.country}`, `${order.bookTitle}\n${order.format}`, new Intl.NumberFormat(undefined,{style:'currency',currency:order.currency}).format(order.amountMinor / 100)];
      for (const value of values) { const td = document.createElement('td'); td.textContent = value; td.style.whiteSpace = 'pre-line'; tr.append(td); }
      const paymentCell = document.createElement('td'); paymentCell.textContent = `${({easypaisa:'Easypaisa',jazzcash:'JazzCash',international_arrangement:'International'})[order.paymentMethod] || order.paymentMethod}\n${order.paymentReference || 'No reference supplied'}`; paymentCell.style.whiteSpace='pre-line'; tr.append(paymentCell);
      const statusCell = document.createElement('td'); const select = document.createElement('select');
      for (const status of ['pending_payment','payment_review','paid','fulfilled','cancelled','refunded']) { const option=document.createElement('option');option.value=status;option.textContent=status.replaceAll('_',' ');option.selected=status===order.status;select.append(option); }
      select.addEventListener('change', async () => { try { await api(`/api/admin/orders/${order.id}`, {method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({status:select.value})}); feedback('ordersFeedback',`Updated ${order.orderNumber}. Only set paid after verifying the payment.`); } catch(e) { feedback('ordersFeedback',e.message,true); } });
      statusCell.append(select); tr.append(statusCell);
      const created=document.createElement('td');created.textContent=order.createdAt;tr.append(created);
      const fileCell=document.createElement('td');
      const download=document.createElement('a');download.textContent='Download';download.href=`/api/admin/download/${order.id}`;download.className='admin-link';download.addEventListener('click',async(e)=>{e.preventDefault();try{const resp=await fetch(download.href,{credentials:'same-origin'});if(!resp.ok){const x=await resp.json().catch(()=>({}));throw new Error(x.error||'Download unavailable.');}const blob=await resp.blob();const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='Think_Like_a_Founder.pdf';a.click();URL.revokeObjectURL(url);}catch(err){feedback('ordersFeedback',err.message,true);}});
      fileCell.append(download);tr.append(fileCell);body.append(tr);
    }
  } catch (error) { feedback('ordersFeedback', error.message, true); }
}
byId('loginForm').addEventListener('submit', async (event) => {
  event.preventDefault();const form=event.currentTarget;const button=form.querySelector('button');button.disabled=true;feedback('loginFeedback','Signing in…');
  try {const data=await api('/api/admin/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(Object.fromEntries(new FormData(form).entries()))});showDashboard(data.admin);}
  catch(error){feedback('loginFeedback',error.message,true);}finally{button.disabled=false;}
});
byId('bookForm').addEventListener('submit',async(event)=>{
  event.preventDefault();const f=event.currentTarget;const p=new URLSearchParams(new FormData(f));
  const payload={title:p.get('title'),subtitle:p.get('subtitle'),description:p.get('description'),priceUsd:Math.round(Number(p.get('priceUsd'))*100),pricePkr:Math.round(Number(p.get('pricePkr'))*100)};
  try{await api('/api/admin/book',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});feedback('bookFeedback','Book details and prices saved.');}
  catch(error){feedback('bookFeedback',error.message,true);}
});
byId('logoutButton').addEventListener('click',async()=>{try{await api('/api/admin/logout',{method:'POST'});}finally{location.reload();}});
(async()=>{try{const data=await api('/api/admin/me');showDashboard(data.admin);}catch(_){/* Login panel remains visible. */}})();
