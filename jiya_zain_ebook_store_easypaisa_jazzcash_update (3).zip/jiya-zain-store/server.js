'use strict';
require('dotenv').config();
const path = require('path');
const fs = require('fs');
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');

const app = express();
const ROOT = __dirname;
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || '';
const DB_PATH = path.resolve(ROOT, process.env.DB_PATH || './data/store.sqlite');
if (JWT_SECRET.length < 32) {
  throw new Error('Set JWT_SECRET in your .env file to a random value with at least 32 characters before starting the server.');
}
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
// Integer minor units: USD cents and PKR paisa. Historic orders store their own price/currency snapshot.
db.exec(`
CREATE TABLE IF NOT EXISTS books (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  subtitle TEXT NOT NULL,
  author TEXT NOT NULL,
  description TEXT NOT NULL,
  cover_path TEXT NOT NULL,
  pdf_private_path TEXT,
  page_count INTEGER,
  edition TEXT,
  price_usd_cents INTEGER NOT NULL CHECK(price_usd_cents >= 0),
  price_pkr_paisa INTEGER NOT NULL CHECK(price_pkr_paisa >= 0),
  is_published INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS admins (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_login_at TEXT
);
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_number TEXT NOT NULL UNIQUE,
  customer_name TEXT NOT NULL,
  email TEXT NOT NULL,
  country TEXT NOT NULL,
  phone TEXT,
  format TEXT NOT NULL CHECK(format IN ('PDF')),
  currency TEXT NOT NULL CHECK(currency IN ('USD','PKR')),
  amount_minor INTEGER NOT NULL CHECK(amount_minor >= 0),
  status TEXT NOT NULL DEFAULT 'pending_payment' CHECK(status IN ('pending_payment','payment_review','paid','fulfilled','cancelled','refunded')),
  customer_note TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  book_id INTEGER REFERENCES books(id) ON DELETE SET NULL,
  title_snapshot TEXT NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 1 CHECK(quantity > 0),
  unit_amount_minor INTEGER NOT NULL,
  currency TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS admin_audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  admin_id INTEGER REFERENCES admins(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT,
  details TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_email ON orders(email);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
`);

// Safe in-place migration for existing SQLite installations.
const orderColumns = db.prepare("PRAGMA table_info(orders)").all().map(column => column.name);
if (!orderColumns.includes('payment_method')) db.exec("ALTER TABLE orders ADD COLUMN payment_method TEXT NOT NULL DEFAULT 'international_arrangement' CHECK(payment_method IN ('easypaisa','jazzcash','international_arrangement'))");
if (!orderColumns.includes('payment_reference')) db.exec("ALTER TABLE orders ADD COLUMN payment_reference TEXT");


const seed = db.prepare(`INSERT OR IGNORE INTO books
(slug,title,subtitle,author,description,cover_path,pdf_private_path,page_count,edition,price_usd_cents,price_pkr_paisa,is_published)
VALUES (@slug,@title,@subtitle,@author,@description,@cover_path,@pdf_private_path,@page_count,@edition,@price_usd_cents,@price_pkr_paisa,1)`);
seed.run({
  slug: 'think-like-a-founder',
  title: 'Think Like a Founder',
  subtitle: 'The Mindset Behind Successful Entrepreneurs',
  author: 'Jiya Zain',
  description: 'Discover the mindset, habits, and principles that turn ordinary ideas into extraordinary businesses—and learn to think like the founders who build them. Across ten chapters, explore vision, confidence, resilience, the growth mindset, risk, discipline, decision-making, leadership, value and adaptability.',
  cover_path: '/assets/book_cover.jpg',
  pdf_private_path: 'private/books/Think_Like_a_Founder.pdf',
  page_count: 178,
  edition: 'First Edition, 2026',
  price_usd_cents: 700,
  price_pkr_paisa: 199900
});

app.disable('x-powered-by');
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'"],
      imgSrc: ["'self'", 'data:'],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
      frameAncestors: ["'none'"]
    }
  },
  crossOriginEmbedderPolicy: false
}));
app.use(express.json({ limit: '30kb' }));
app.use(cookieParser());
app.use(express.static(path.join(ROOT, 'public'), { index: 'index.html', maxAge: process.env.NODE_ENV === 'production' ? '1h' : 0 }));
app.use('/api/admin/login', rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false }));
app.use('/api/orders', rateLimit({ windowMs: 60 * 60 * 1000, limit: 15, standardHeaders: true, legacyHeaders: false }));

function publicBook(row) {
  if (!row) return null;
  return {
    id: row.id, slug: row.slug, title: row.title, subtitle: row.subtitle,
    author: row.author, description: row.description, cover: row.cover_path,
    pages: row.page_count, edition: row.edition,
    price: { USD: row.price_usd_cents, PKR: row.price_pkr_paisa }
  };
}
function requireAdmin(req, res, next) {
  const token = req.cookies.jiya_admin;
  if (!token) return res.status(401).json({ error: 'Admin login required.' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.admin = { id: payload.sub, email: payload.email };
    next();
  } catch (_) { return res.status(401).json({ error: 'Your admin session has expired. Please sign in again.' }); }
}
function cleanText(value, max = 5000) { return typeof value === 'string' ? value.trim().slice(0, max) : ''; }
function audit(adminId, action, entityType, entityId, details) {
  db.prepare('INSERT INTO admin_audit_logs (admin_id,action,entity_type,entity_id,details) VALUES (?,?,?,?,?)')
    .run(adminId, action, entityType, String(entityId ?? ''), JSON.stringify(details || {}));
}

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'jiya-zain-bookstore', database: 'connected' }));
app.get('/api/book', (_req, res) => {
  const row = db.prepare('SELECT * FROM books WHERE slug=? AND is_published=1').get('think-like-a-founder');
  if (!row) return res.status(404).json({ error: 'Book not found.' });
  res.json({ book: publicBook(row) });
});

app.post('/api/orders', (req, res) => {
  const name = cleanText(req.body?.name, 120);
  const email = cleanText(req.body?.email, 200).toLowerCase();
  const country = cleanText(req.body?.country, 100);
  const phone = cleanText(req.body?.phone, 40);
  const note = cleanText(req.body?.note, 1000);
  const paymentMethod = cleanText(req.body?.paymentMethod, 40);
  const paymentReference = cleanText(req.body?.paymentReference, 100);
  const currency = req.body?.currency === 'PKR' ? 'PKR' : 'USD';
  const format = req.body?.format === 'PDF' ? 'PDF' : '';
  if (name.length < 2) return res.status(400).json({ error: 'Please enter your full name.' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'Please enter a valid email address.' });
  if (!country || !format) return res.status(400).json({ error: 'Please select your country and an available format.' });
  const allowedMethods = ['easypaisa','jazzcash','international_arrangement'];
  if (!allowedMethods.includes(paymentMethod)) return res.status(400).json({ error: 'Please select a valid payment method.' });
  if (country.toLowerCase() === 'pakistan' && !['easypaisa','jazzcash'].includes(paymentMethod)) return res.status(400).json({ error: 'For Pakistan orders, choose Easypaisa or JazzCash.' });
  if (country.toLowerCase() !== 'pakistan' && paymentMethod !== 'international_arrangement') return res.status(400).json({ error: 'Easypaisa and JazzCash are available for Pakistan orders only.' });
  if (country.toLowerCase() === 'pakistan' && currency !== 'PKR') return res.status(400).json({ error: 'Pakistan orders must use PKR pricing.' });
  if (country.toLowerCase() !== 'pakistan' && currency !== 'USD') return res.status(400).json({ error: 'International orders must use USD pricing.' });
  const book = db.prepare('SELECT * FROM books WHERE slug=? AND is_published=1').get('think-like-a-founder');
  if (!book) return res.status(404).json({ error: 'This book is not currently available.' });
  const amount = currency === 'PKR' ? book.price_pkr_paisa : book.price_usd_cents;
  const orderNumber = `JZ-${new Date().toISOString().slice(0,10).replaceAll('-','')}-${Math.random().toString(36).slice(2,8).toUpperCase()}`;
  const insertOrder = db.prepare(`INSERT INTO orders (order_number,customer_name,email,country,phone,format,currency,amount_minor,status,customer_note,payment_method,payment_reference)
    VALUES (?,?,?,?,?,?,?,?, ?,?,?,?)`);
  const insertItem = db.prepare(`INSERT INTO order_items (order_id,book_id,title_snapshot,quantity,unit_amount_minor,currency) VALUES (?,?,?,?,?,?)`);
  const create = db.transaction(() => {
    const info = insertOrder.run(orderNumber,name,email,country,phone,format,currency,amount,paymentReference ? 'payment_review' : 'pending_payment',note,paymentMethod,paymentReference || null);
    insertItem.run(info.lastInsertRowid,book.id,book.title,1,amount,currency);
  });
  create();
  res.status(201).json({ success: true, orderNumber, status: paymentReference ? 'payment_review' : 'pending_payment', currency, amountMinor: amount, paymentMethod, paymentMethodLabel: ({easypaisa:'Easypaisa',jazzcash:'JazzCash',international_arrangement:'International payment arrangement'})[paymentMethod],
    message: 'Your order request has been saved. This is not a payment confirmation. The store owner will send verified payment instructions and verify any transaction reference.' });
});

app.post('/api/admin/login', (req, res) => {
  const email = cleanText(req.body?.email, 200).toLowerCase();
  const password = typeof req.body?.password === 'string' ? req.body.password : '';
  const admin = db.prepare('SELECT * FROM admins WHERE email=?').get(email);
  if (!admin || !bcrypt.compareSync(password, admin.password_hash)) return res.status(401).json({ error: 'Email or password is incorrect.' });
  const token = jwt.sign({ sub: admin.id, email: admin.email }, JWT_SECRET, { expiresIn: '8h' });
  db.prepare('UPDATE admins SET last_login_at=CURRENT_TIMESTAMP WHERE id=?').run(admin.id);
  res.cookie('jiya_admin', token, { httpOnly: true, secure: process.env.COOKIE_SECURE === 'true', sameSite: 'strict', maxAge: 8*60*60*1000, path: '/' });
  res.json({ success: true, admin: { email: admin.email } });
});
app.post('/api/admin/logout', (_req, res) => { res.clearCookie('jiya_admin', { httpOnly: true, secure: process.env.COOKIE_SECURE === 'true', sameSite: 'strict', path: '/' }); res.json({ success: true }); });
app.get('/api/admin/me', requireAdmin, (req, res) => res.json({ admin: req.admin }));
app.get('/api/admin/book', requireAdmin, (_req, res) => {
  const row = db.prepare('SELECT * FROM books WHERE slug=?').get('think-like-a-founder');
  res.json({ book: publicBook(row) });
});
app.patch('/api/admin/book', requireAdmin, (req, res) => {
  const title = cleanText(req.body?.title, 160);
  const subtitle = cleanText(req.body?.subtitle, 220);
  const description = cleanText(req.body?.description, 3000);
  const usd = Number(req.body?.priceUsd);
  const pkr = Number(req.body?.pricePkr);
  if (title.length < 3 || subtitle.length < 3 || description.length < 20) return res.status(400).json({ error: 'Please complete the book title, subtitle and description.' });
  if (!Number.isInteger(usd) || usd < 1 || usd > 1000000 || !Number.isInteger(pkr) || pkr < 1 || pkr > 100000000) return res.status(400).json({ error: 'Enter valid prices. USD is in cents; PKR is in paisa.' });
  db.prepare(`UPDATE books SET title=?,subtitle=?,description=?,price_usd_cents=?,price_pkr_paisa=?,updated_at=CURRENT_TIMESTAMP WHERE slug=?`)
    .run(title,subtitle,description,usd,pkr,'think-like-a-founder');
  audit(req.admin.id,'update','book','think-like-a-founder',{title,priceUsdCents:usd,pricePkrPaisa:pkr});
  const row = db.prepare('SELECT * FROM books WHERE slug=?').get('think-like-a-founder');
  res.json({ success: true, book: publicBook(row) });
});
app.get('/api/admin/orders', requireAdmin, (_req, res) => {
  const rows = db.prepare(`SELECT o.*, (SELECT title_snapshot FROM order_items i WHERE i.order_id=o.id LIMIT 1) AS book_title
    FROM orders o ORDER BY o.id DESC LIMIT 200`).all();
  res.json({ orders: rows.map(o => ({ id:o.id,orderNumber:o.order_number,name:o.customer_name,email:o.email,country:o.country,phone:o.phone,format:o.format,currency:o.currency,amountMinor:o.amount_minor,status:o.status,note:o.customer_note,paymentMethod:o.payment_method,paymentReference:o.payment_reference,createdAt:o.created_at,bookTitle:o.book_title })) });
});
app.patch('/api/admin/orders/:id', requireAdmin, (req, res) => {
  const allowed = ['pending_payment','payment_review','paid','fulfilled','cancelled','refunded'];
  const status = req.body?.status;
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || !allowed.includes(status)) return res.status(400).json({ error: 'Invalid order or status.' });
  const result = db.prepare('UPDATE orders SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(status,id);
  if (!result.changes) return res.status(404).json({ error: 'Order not found.' });
  audit(req.admin.id,'update_status','order',id,{status});
  res.json({ success:true });
});
app.get('/admin', (_req,res) => res.sendFile(path.join(ROOT,'public','admin.html')));
app.get('/api/admin/download/:orderId', requireAdmin, (req,res) => {
  const order = db.prepare('SELECT status,format FROM orders WHERE id=?').get(Number(req.params.orderId));
  if (!order || !['paid','fulfilled'].includes(order.status)) return res.status(403).json({ error:'Mark the order paid before downloading the file.' });
  const book = db.prepare('SELECT pdf_private_path FROM books WHERE slug=?').get('think-like-a-founder');
  const filePath = path.resolve(ROOT, book.pdf_private_path);
  if (!filePath.startsWith(path.resolve(ROOT,'private') + path.sep) || !fs.existsSync(filePath)) return res.status(404).json({ error:'Private book file is unavailable.' });
  res.download(filePath,'Think_Like_a_Founder.pdf');
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'An unexpected server error occurred.' });
});
app.listen(PORT, () => console.log(`Jiya Zain bookstore running at http://localhost:${PORT}`));
