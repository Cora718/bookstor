'use strict';
require('dotenv').config();
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');
(async () => {
  const root = path.resolve(__dirname, '..');
  const source = path.resolve(root, process.env.DB_PATH || './data/store.sqlite');
  if (!fs.existsSync(source)) throw new Error(`Database not found: ${source}`);
  const directory = path.join(root, 'backups');
  fs.mkdirSync(directory, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const target = path.join(directory, `store-${stamp}.sqlite`);
  const db = new Database(source, { readonly: true, fileMustExist: true });
  try { await db.backup(target); }
  finally { db.close(); }
  console.log(`Database backup created: ${target}`);
})().catch((error) => { console.error(error.message); process.exit(1); });
