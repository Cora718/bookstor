'use strict';
require('dotenv').config();
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const [emailArg, password] = process.argv.slice(2);
const email = String(emailArg || '').trim().toLowerCase();
if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
  console.error('Usage: npm run create-admin -- admin@example.com "A-strong-password"'); process.exit(1);
}
if (!password || password.length < 12) { console.error('Use an admin password of at least 12 characters.'); process.exit(1); }
const root = path.resolve(__dirname, '..');
const dbPath = path.resolve(root, process.env.DB_PATH || './data/store.sqlite');
if (!fs.existsSync(dbPath)) { console.error('Database not found. Start the server once to initialize it, then run this command.'); process.exit(1); }
const db = new Database(dbPath);
const hash = bcrypt.hashSync(password, 12);
try {
  db.prepare('INSERT INTO admins (email,password_hash) VALUES (?,?)').run(email, hash);
  console.log(`Admin account created for ${email}`);
} catch (error) {
  if (String(error.message).includes('UNIQUE')) console.error('That admin email already exists.');
  else console.error(error.message);
  process.exitCode = 1;
} finally { db.close(); }
