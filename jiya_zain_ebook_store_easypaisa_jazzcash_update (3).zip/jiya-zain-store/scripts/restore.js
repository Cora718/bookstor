'use strict';
require('dotenv').config();
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');
(async () => {
  const root = path.resolve(__dirname, '..');
  const supplied = process.argv[2];
  if (!supplied) throw new Error('Usage: npm run restore -- backups/store-backup.sqlite');
  const source = path.resolve(root, supplied);
  const target = path.resolve(root, process.env.DB_PATH || './data/store.sqlite');
  if (!source.startsWith(root + path.sep) || !fs.existsSync(source)) throw new Error('Backup file must exist inside the project folder.');
  const check = new Database(source, { readonly: true, fileMustExist: true });
  try {
    const result = check.pragma('integrity_check', { simple: true });
    if (result !== 'ok') throw new Error(`Backup integrity check failed: ${result}`);
    const tables = check.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map(x => x.name);
    if (!tables.includes('books') || !tables.includes('orders')) throw new Error('This file does not look like a bookstore database backup.');
  } finally { check.close(); }
  if (fs.existsSync(target)) {
    const db = new Database(target);
    try { await db.backup(`${target}.before-restore-${Date.now()}.sqlite`); }
    finally { db.close(); }
  }
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.copyFileSync(source, target);
  console.log(`Database restored from ${source}`);
})().catch((error) => { console.error(error.message); process.exit(1); });
