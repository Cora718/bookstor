INSERT OR IGNORE INTO books
(slug,title,subtitle,author,description,cover_path,pdf_private_path,page_count,edition,price_usd_cents,price_pkr_paisa,is_published)
VALUES
('think-like-a-founder','Think Like a Founder','The Mindset Behind Successful Entrepreneurs','Jiya Zain',
'Discover the mindset, habits, and principles that turn ordinary ideas into extraordinary businesses—and learn to think like the founders who build them. Across ten chapters, explore vision, confidence, resilience, the growth mindset, risk, discipline, decision-making, leadership, value and adaptability.',
'/assets/book_cover.jpg','private/books/Think_Like_a_Founder.pdf',178,'First Edition, 2026',700,199900,1);
